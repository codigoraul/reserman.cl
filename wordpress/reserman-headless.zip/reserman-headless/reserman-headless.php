<?php
/**
 * Plugin Name: Reserman Headless
 * Description: Servicios y datos de contacto editables para el sitio Astro de reserman.cl (WordPress headless). Sin dependencias (no requiere ACF).
 * Version: 1.0.2
 * Author: DiseñoPaginas.cl
 */

if (!defined('ABSPATH')) exit;

const RM_ICONOS = [
    'proyectos'     => 'Proyectos (portapapeles)',
    'soldadura'     => 'Soldadura (llama)',
    'mantenimiento' => 'Mantenimiento (llave)',
    'montaje'       => 'Montaje (gancho)',
    'electrica'     => 'Eléctrica (rayo)',
    'civiles'       => 'Obras civiles (muro)',
];

/* ───────────── Servicios (CPT) ───────────── */

function rm_register_cpt() {
    register_post_type('servicio', [
        'labels' => [
            'name'          => 'Servicios',
            'singular_name' => 'Servicio',
            'add_new_item'  => 'Agregar servicio',
            'edit_item'     => 'Editar servicio',
            'all_items'     => 'Todos los servicios',
        ],
        'public'             => false,
        'publicly_queryable' => false,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'menu_icon'          => 'dashicons-hammer',
        'menu_position'      => 20,
        'show_in_rest'       => true,
        'rest_base'          => 'servicio',
        'supports'           => ['title', 'editor', 'thumbnail', 'page-attributes'],
        'has_archive'        => false,
    ]);
}
add_action('init', 'rm_register_cpt');

/* Metabox con los campos propios del servicio */
function rm_add_metabox() {
    add_meta_box('rm_servicio', 'Datos del servicio', 'rm_metabox_html', 'servicio', 'normal', 'high');
}
add_action('add_meta_boxes', 'rm_add_metabox');

function rm_metabox_html($post) {
    wp_nonce_field('rm_servicio_save', 'rm_servicio_nonce');
    $resumen = get_post_meta($post->ID, '_rm_resumen', true);
    $corto   = get_post_meta($post->ID, '_rm_titulo_corto', true);
    $icono   = get_post_meta($post->ID, '_rm_icono', true) ?: 'proyectos';
    $items   = get_post_meta($post->ID, '_rm_items', true);
    ?>
    <p><label><strong>Resumen</strong> (texto breve que aparece en la tarjeta y bajo el título)</label><br>
        <textarea name="rm_resumen" rows="3" style="width:100%"><?php echo esc_textarea($resumen); ?></textarea></p>
    <p><label><strong>Título corto</strong> (menú y footer; si se deja vacío usa el título)</label><br>
        <input type="text" name="rm_titulo_corto" value="<?php echo esc_attr($corto); ?>" style="width:100%"></p>
    <p><label><strong>Ícono</strong></label><br>
        <select name="rm_icono">
            <?php foreach (RM_ICONOS as $k => $label): ?>
                <option value="<?php echo esc_attr($k); ?>" <?php selected($icono, $k); ?>><?php echo esc_html($label); ?></option>
            <?php endforeach; ?>
        </select></p>
    <p><label><strong>Lista “Incluye”</strong> (una línea por ítem; aparece en la barra lateral y en la tarjeta)</label><br>
        <textarea name="rm_items" rows="6" style="width:100%"><?php echo esc_textarea($items); ?></textarea></p>
    <p class="description">
        Imagen: usa “Imagen destacada” (panel derecho, 900×700 px recomendado).
        Orden: campo “Orden” en Atributos de página (número menor aparece primero).
        El texto largo del servicio se escribe en el editor principal.
    </p>
    <?php
}

function rm_save_servicio($post_id) {
    if (!isset($_POST['rm_servicio_nonce']) || !wp_verify_nonce($_POST['rm_servicio_nonce'], 'rm_servicio_save')) return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) return;
    if (!current_user_can('edit_post', $post_id)) return;

    update_post_meta($post_id, '_rm_resumen', sanitize_textarea_field(wp_unslash($_POST['rm_resumen'] ?? '')));
    update_post_meta($post_id, '_rm_titulo_corto', sanitize_text_field(wp_unslash($_POST['rm_titulo_corto'] ?? '')));
    $icono = sanitize_key($_POST['rm_icono'] ?? 'proyectos');
    update_post_meta($post_id, '_rm_icono', isset(RM_ICONOS[$icono]) ? $icono : 'proyectos');
    update_post_meta($post_id, '_rm_items', sanitize_textarea_field(wp_unslash($_POST['rm_items'] ?? '')));
}
add_action('save_post_servicio', 'rm_save_servicio');

/* Campo `acf` en la REST API (misma forma que espera src/lib/wp.ts) */
add_action('rest_api_init', function () {
    register_rest_field('servicio', 'acf', [
        'get_callback' => function ($obj) {
            $id    = $obj['id'];
            $items = array_values(array_filter(array_map('trim', explode("\n", (string) get_post_meta($id, '_rm_items', true)))));
            $icono = get_post_meta($id, '_rm_icono', true);
            return [
                'resumen'      => (string) get_post_meta($id, '_rm_resumen', true),
                'titulo_corto' => (string) get_post_meta($id, '_rm_titulo_corto', true) ?: null,
                'icono'        => isset(RM_ICONOS[$icono]) ? $icono : 'proyectos',
                'items'        => $items,
                'orden'        => (int) get_post_field('menu_order', $id),
                'destacado'    => false,
            ];
        },
        'schema' => null,
    ]);

    register_rest_route('reserman/v1', '/contacto', [
        'methods'             => 'GET',
        'permission_callback' => '__return_true',
        'callback'            => 'rm_rest_contacto',
    ]);
});

/* ───────────── Datos de contacto (página de ajustes) ───────────── */

function rm_contacto_campos() {
    return [
        'empresa'   => ['Nombre de la empresa', 'Reserman SpA'],
        'tagline'   => ['Tagline del logo', 'Soluciones Industriales'],
        'lema'      => ['Lema', 'Compromiso – Excelencia – Confianza'],
        'telefono'  => ['Teléfono (con código país, ej. +56 9 9099 4623)', '+56 9 9099 4623'],
        'whatsapp'  => ['WhatsApp (solo dígitos con código país, ej. 56990994623)', '56990994623'],
        'email'     => ['Email', 'contacto@reserman.cl'],
        'direccion' => ['Dirección', 'Guardia Vieja 202, Oficina 902'],
        'comuna'    => ['Comuna', 'Providencia'],
        'ciudad'    => ['Ciudad', 'Santiago, Chile'],
        'horario'   => ['Horario', 'Lunes a viernes, 08:30 – 18:00 hrs'],
        'linkedin'  => ['LinkedIn (URL)', 'https://www.linkedin.com/company/reserman-spa'],
        'instagram' => ['Instagram (URL)', 'https://www.instagram.com/resermanspa/'],
        'facebook'  => ['Facebook (URL, opcional)', ''],
    ];
}

function rm_get_contacto() {
    $saved = get_option('reserman_contacto', []);
    $out = [];
    foreach (rm_contacto_campos() as $k => $def) {
        $out[$k] = isset($saved[$k]) ? $saved[$k] : $def[1];
    }
    return $out;
}

function rm_rest_contacto() {
    return rest_ensure_response(rm_get_contacto());
}

add_action('admin_menu', function () {
    add_menu_page('Reserman', 'Reserman', 'edit_pages', 'reserman-ajustes', 'rm_ajustes_html', 'dashicons-building', 21);
});

add_filter('option_page_capability_reserman_ajustes', function () { return 'edit_pages'; });

add_action('admin_init', function () {
    register_setting('reserman_ajustes', 'reserman_contacto', [
        'sanitize_callback' => function ($in) {
            $out = [];
            foreach (rm_contacto_campos() as $k => $def) {
                $v = isset($in[$k]) ? wp_unslash($in[$k]) : '';
                $out[$k] = in_array($k, ['linkedin', 'instagram', 'facebook'], true) ? esc_url_raw($v) : sanitize_text_field($v);
            }
            $out['email'] = sanitize_email($out['email']);
            $out['whatsapp'] = preg_replace('/\D/', '', $out['whatsapp']);
            return $out;
        },
    ]);
    register_setting('reserman_ajustes', 'reserman_deploy_url', ['sanitize_callback' => function ($v) {
        return current_user_can('manage_options') ? esc_url_raw($v) : get_option('reserman_deploy_url', '');
    }]);
    register_setting('reserman_ajustes', 'reserman_deploy_token', ['sanitize_callback' => function ($v) {
        return current_user_can('manage_options') ? sanitize_text_field($v) : get_option('reserman_deploy_token', '');
    }]);
});

function rm_ajustes_html() {
    if (!current_user_can('edit_pages')) return;
    $es_admin = current_user_can('manage_options');
    $vals = rm_get_contacto();
    ?>
    <div class="wrap">
        <h1>Reserman — Datos de contacto</h1>
        <p>Estos datos se muestran en el sitio (barra superior, footer, contacto y botón de WhatsApp).</p>
        <form method="post" action="options.php">
            <?php settings_fields('reserman_ajustes'); ?>
            <table class="form-table" role="presentation">
                <?php foreach (rm_contacto_campos() as $k => $def): ?>
                    <tr>
                        <th scope="row"><label for="rm_<?php echo esc_attr($k); ?>"><?php echo esc_html($def[0]); ?></label></th>
                        <td><input type="text" class="regular-text" id="rm_<?php echo esc_attr($k); ?>"
                                   name="reserman_contacto[<?php echo esc_attr($k); ?>]"
                                   value="<?php echo esc_attr($vals[$k]); ?>"></td>
                    </tr>
                <?php endforeach; ?>
            </table>

            <?php if ($es_admin): ?>
            <h2>Publicación automática (solo administrador)</h2>
            <p>El sitio es estático: al guardar cambios se debe reconstruir. Si se configura una URL, el plugin la llama cada vez que se guarda un servicio o los datos de contacto. Esta sección no la ve el usuario cliente.</p>
            <table class="form-table" role="presentation">
                <tr>
                    <th scope="row"><label for="rm_deploy_url">URL de despliegue</label></th>
                    <td><input type="url" class="regular-text" id="rm_deploy_url" name="reserman_deploy_url"
                               value="<?php echo esc_attr(get_option('reserman_deploy_url', '')); ?>"
                               placeholder="https://api.github.com/repos/USUARIO/REPO/dispatches"></td>
                </tr>
                <tr>
                    <th scope="row"><label for="rm_deploy_token">Token (opcional)</label></th>
                    <td><input type="password" class="regular-text" id="rm_deploy_token" name="reserman_deploy_token"
                               value="<?php echo esc_attr(get_option('reserman_deploy_token', '')); ?>" autocomplete="off">
                        <p class="description">Con token se envía como GitHub <code>repository_dispatch</code> (evento <code>wp-update</code>); sin token, un POST simple.</p></td>
                </tr>
            </table>
            <?php endif; ?>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/* ───────────── Aviso de despliegue (se configura en Reserman → solo administrador) ───────────── */

function rm_trigger_deploy() {
    $url = get_option('reserman_deploy_url', '') ?: (defined('RESERMAN_DEPLOY_URL') ? RESERMAN_DEPLOY_URL : '');
    if (!$url || get_transient('rm_deploy_lock')) return;
    set_transient('rm_deploy_lock', 1, 60); // evita ráfagas: máximo una llamada por minuto
    $token = get_option('reserman_deploy_token', '') ?: (defined('RESERMAN_DEPLOY_TOKEN') ? RESERMAN_DEPLOY_TOKEN : '');
    $args = ['timeout' => 5, 'blocking' => false, 'headers' => ['Content-Type' => 'application/json'], 'body' => '{}'];
    if ($token) {
        $args['headers']['Authorization'] = 'Bearer ' . $token;
        $args['headers']['Accept'] = 'application/vnd.github+json';
        $args['body'] = wp_json_encode(['event_type' => 'wp-update']);
    }
    wp_remote_post($url, $args);
}
add_action('save_post_servicio', function ($id, $post) {
    if (wp_is_post_revision($id) || (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)) return;
    if ($post->post_status === 'auto-draft') return;
    rm_trigger_deploy();
}, 20, 2);
add_action('trashed_post', function ($id) { if (get_post_type($id) === 'servicio') rm_trigger_deploy(); });
add_action('update_option_reserman_contacto', 'rm_trigger_deploy');

/* ───────────── Carga inicial (al activar) ───────────── */

register_activation_hook(__FILE__, function () {
    rm_register_cpt();
    flush_rewrite_rules();

    $seed_file = __DIR__ . '/seed/seed.json';
    if (!file_exists($seed_file)) return;
    $seed = json_decode(file_get_contents($seed_file), true);
    if (!$seed) return;

    // Contacto: solo si no hay datos guardados
    if (!get_option('reserman_contacto')) {
        $c = $seed['contacto'];
        update_option('reserman_contacto', [
            'empresa'   => $c['empresa'], 'tagline' => $c['tagline'], 'lema' => $c['lema'],
            'telefono'  => $c['telefono'], 'whatsapp' => $c['whatsapp'], 'email' => $c['email'],
            'direccion' => $c['direccion'], 'comuna' => $c['comuna'], 'ciudad' => $c['ciudad'],
            'horario'   => $c['horario'],
            'linkedin'  => $c['redes']['linkedin'] ?? '', 'instagram' => $c['redes']['instagram'] ?? '', 'facebook' => '',
        ]);
    }

    // Servicios: solo si no existe ninguno
    $existentes = get_posts(['post_type' => 'servicio', 'post_status' => 'any', 'numberposts' => 1, 'fields' => 'ids']);
    if ($existentes) return;

    require_once ABSPATH . 'wp-admin/includes/file.php';
    require_once ABSPATH . 'wp-admin/includes/media.php';
    require_once ABSPATH . 'wp-admin/includes/image.php';

    foreach ($seed['servicios'] as $s) {
        $id = wp_insert_post([
            'post_type'    => 'servicio',
            'post_status'  => 'publish',
            'post_title'   => $s['titulo'],
            'post_name'    => $s['slug'],
            'post_content' => $s['contenido'],
            'menu_order'   => (int) $s['orden'],
        ]);
        if (is_wp_error($id) || !$id) continue;
        update_post_meta($id, '_rm_resumen', $s['resumen']);
        update_post_meta($id, '_rm_titulo_corto', $s['tituloCorto']);
        update_post_meta($id, '_rm_icono', $s['icono']);
        update_post_meta($id, '_rm_items', implode("\n", $s['items']));

        $src = __DIR__ . '/seed/images/' . $s['imagen'];
        if (file_exists($src)) {
            $tmp = wp_tempnam($s['imagen']);
            copy($src, $tmp);
            $att = media_handle_sideload(['name' => $s['imagen'], 'tmp_name' => $tmp], $id);
            if (!is_wp_error($att)) set_post_thumbnail($id, $att);
            else @unlink($tmp);
        }
    }
});
